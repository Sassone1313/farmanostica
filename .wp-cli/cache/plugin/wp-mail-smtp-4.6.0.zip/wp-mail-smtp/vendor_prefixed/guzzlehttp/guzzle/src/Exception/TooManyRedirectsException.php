<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends \WPMailSMTP\Vendor\GuzzleHttp\Exception\RequestException
{
}
