import './loading.scss';

export default function Loading() {
    return (
      <div className="loading-wrapper">
        <div className="loading-container" >
        <span className="loader"></span>
      </div>
      </div>
    )
}