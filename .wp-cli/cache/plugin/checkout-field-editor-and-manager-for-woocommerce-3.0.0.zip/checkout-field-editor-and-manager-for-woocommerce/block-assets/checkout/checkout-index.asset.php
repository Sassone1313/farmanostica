<?php return array('dependencies' => array(), 'version' => '6bb137eb9b92fd63dc86');
