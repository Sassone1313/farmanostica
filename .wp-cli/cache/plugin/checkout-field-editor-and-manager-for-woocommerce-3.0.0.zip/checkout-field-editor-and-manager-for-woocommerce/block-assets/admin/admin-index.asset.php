<?php return array('dependencies' => array('react', 'react-dom'), 'version' => 'b0077c2c3e2b2d5e6218');
