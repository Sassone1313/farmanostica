window.IVS_AJAX_JS_LOAD = function() {
	'use strict';

        jQuery( document ).ready( function($) {
		var _ref = null;
                var old_search_term = '';
                var old_form_id = -1;
                var ajax;
                var focused = $( document.activeElement ).closest('form');

		$('body').on('mouseover', '.is-ajax-search-tags > div, .is-ajax-search-categories > div, .is-ajax-search-post.is-product', function(event) {

			var window_width = $(window).outerWidth();
			if( parseInt( window_width ) >= 910 ) {
                            var id = $(this).attr('data-id') || '';
                            var search_results = $(event.target).closest('.is-ajax-search-result').attr('id');
                            var form_id = search_results.split(/[-]+/).pop();
                            var results_pos = $( '#is-ajax-search-result-'+form_id ).offset();
                            var result_box_max_height = $( '.is-form-id-'+form_id ).attr('data-result-box-max-height') || '400';
                            $( '#is-ajax-search-details-'+form_id ).css({
                                top: ( results_pos.top ) + "px"
                            });
                            $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-items' ).css( 'height', result_box_max_height + 'px' );
                            $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-items > div' ).css( 'min-height', result_box_max_height + 'px' );

                            if ( $( this ).parents('div').hasClass('is-ajax-search-tags') && $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details' ).length && $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details > div[data-id="'+id+'"]' ).length ) {
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details, #is-ajax-search-details-'+form_id ).show();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details, #is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details' ).hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details' ).find(' > div ').hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details' ).find(' > div[data-id="'+id+'"] ').show();
                            } else if( $( this ).parents('div').hasClass('is-ajax-search-categories') && $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details' ).length && $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details > div[data-id="'+id+'"]' ).length ) {
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details, #is-ajax-search-details-'+form_id ).show();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details, #is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details' ).hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details' ).find('> div ').hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details' ).find('> div[data-id="'+id+'"] ').show();
                            } else if( $( this ).parents('div').hasClass('is-ajax-search-posts') ) {
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-tags-details, #is-ajax-search-details-'+form_id+' .is-ajax-search-categories-details' ).hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details' ).find('> div ').hide();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details, #is-ajax-search-details-'+form_id ).show();
                                    $( '#is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details' ).find('> div[data-id="'+id+'"] ').show();
                            }
			}
		});

            $('.is-ajax-search .is-search-input').on('focusin, click', function(event) {
                focused = $( this ).closest('form');
                if ( '' !== $( this ).val() && 0 === $(event.target).closest('form.processing').length ) {
                    var form_id = $( event.target ).closest('.is-ajax-search').attr('data-form-id');
                    var width = $( event.target ).closest('.is-ajax-search').outerWidth();
                    width = ( width < 500 ) ? 500 : width;
                    $('#is-ajax-search-result-'+form_id).css({
                        width: ( width - 10 ) + "px",
                    });
                    var pos = $( event.target ).closest('.is-ajax-search').offset();
                    var height = $( event.target ).closest('.is-ajax-search').innerHeight();
                    var result_width = $( '#is-ajax-search-result-'+form_id ).outerWidth();
                    var window_width = $(window).width();
                    var reduce_left_pos = 0;

                    if ( ( pos.left + result_width ) > window_width ) {
                        reduce_left_pos = ( pos.left + result_width ) - window_width;
                    }
                    $('#is-ajax-search-result-'+form_id).css({
                        top: (pos.top+height) + "px",
                        left: (pos.left-reduce_left_pos) + "px"
                    });

                    $( '.is-ajax-search-result, .is-ajax-search-details' ).hide();
                    $('#is-ajax-search-result-'+form_id).show();

                    if ( 0 !== $( '#is-ajax-search-details-'+form_id ).length ) {
                        var details_width = $( '#is-ajax-search-details-'+form_id ).outerWidth();
                        var details_left = pos.left+result_width;
                        if ( ( pos.left + result_width + details_width ) > ( window_width + 30 ) ) {
                            var temp = pos.left - ( reduce_left_pos + details_width );
                            if ( temp > -30 ) {
                                details_left = temp;
                            }
                        }
                        $('#is-ajax-search-details-'+form_id).css({
                            top: (pos.top+height) + "px",
                            left: (details_left) + "px"
                        });
                    }
                }
            });


            $('body').on( 'mousedown', function(event) {
	        if ( 0 === event.button &&'s' !== $(event.target).attr('name') && 0 === $(event.target).closest('.is-ajax-search-result').length && 0 === $(event.target).closest('.is-ajax-search-details').length ) {
	        	$( '.is-ajax-search-result, .is-ajax-search-details' ).hide();
                focused = false;
	        }
	    });

            $('.is-disable-submit .is-search-submit').on('click', function(event) {
                $(this).parent().find('.is-search-input').trigger("keyup");
                event.stopPropagation();
                event.preventDefault();
                return false;
            });


            $( document ).on('click', '.is-show-more-results', function(event) {

                var search_results = $(event.target).closest('.is-ajax-search-result').attr('id');
                var form_id = search_results.split(/[-]+/).pop();

                if ( $(this).hasClass( 'redirect-tosr' ) ) {
                    $( '.is-form-id-' + form_id ).submit();
                    return;
                }

                $(this).find('.is-show-more-results-text').hide();
                $(this).find('.is-load-more-image').show();

                var self = $( '.is-form-id-'+form_id+' .is-search-input' );
                var page = $(this).attr('data-page') || '';

                is_ajax_process_request( self, page );
	    });
            
            $(window).on('resize scroll', function(){
                if ( $( focused ).hasClass( 'is-ajax-search' ) && '' !== $( focused ).find('.is-search-input').val() ) {

                    var form_id = $( focused ).attr( 'data-form-id' );

                    if ( 0 !== $('#is-ajax-search-result-'+form_id).length ) {

                    var pos = $( focused ).offset();
                    var height = $( focused ).innerHeight();
                    var result_width = $( '#is-ajax-search-result-'+form_id ).outerWidth();
                    var window_width = $(window).width();
                    var reduce_left_pos = 0;
                    if ( ( pos.left + result_width ) > window_width ) {
                        reduce_left_pos = ( pos.left + result_width ) - window_width;
                    }
                    $('#is-ajax-search-result-'+form_id).css({
                        top: (pos.top+height) + "px",
                        left: (pos.left-reduce_left_pos) + "px"
                    });

                    $('#is-ajax-search-result-'+form_id).show();

                    if ( 0 !== $( '#is-ajax-search-details-'+form_id ).length ) {
                        var details_width = $( '#is-ajax-search-details-'+form_id ).outerWidth();
                        var details_left = pos.left+result_width;
                        if ( ( pos.left + result_width + details_width ) > ( window_width + 30 ) ) {
                            var temp = pos.left - ( reduce_left_pos + details_width );
                            if ( temp > -30 ) {
                                details_left = temp;
                            }
                        }
                        $('#is-ajax-search-details-'+form_id).css({
                            top: (pos.top+height) + "px",
                            left: (details_left) + "px"
                        });
                    }
                    }
                }
            });

            $('.is-ajax-search .is-search-input').on('paste', function() {
                $(this).trigger("keyup");
            });

            $('.is-ajax-search').each(function(index, el) {
                    $( el ).find('.is-search-input').on('keyup', function( event ) {
                        focused = $( this ).closest('form');
                        if ( 32 !== event.which ) {
                            var self = this;
                            window.clearTimeout( _ref );
                            _ref = window.setTimeout(function () {
                                    _ref = null;
                                    is_ajax_process_request( self );
                            }, 500);
                        }
                        if ( 13 === event.which ) {
                            event.stopPropagation();
                            event.preventDefault();
                            return false;
                        }
                    });
            });

            $('form.is-ajax-search.is-disable-submit').on('submit', function( event ) {
                if ( ! $('.is-show-more-results.redirect-tosr').length ) {
                    event.stopPropagation();
                    event.preventDefault();
                    return false;
                }
            });

		function is_ajax_process_request( self, page ) {

			if( ! page ) {
				page = 1;
			}

			var input_box         = $( self );
			var search_term       = input_box.val() || '';
			var search_form       = input_box.parents('.is-ajax-search');
			var min_no_for_search = search_form.attr('data-min-no-for-search') || '';
			var result_box_max_height = search_form.attr('data-result-box-max-height') || '400';
                        var form_id = $(search_form).attr('data-form-id');
                        $( '.is-form-id-'+form_id+' .is-search-input' ).val( search_term );

                        if ( '' === old_search_term || old_search_term !== search_term.trim() || old_form_id !== form_id ) {
                            old_search_term = search_term.trim();
                            old_form_id = form_id;
                        } else if ( 1 === page ) {
                            $( '#is-ajax-search-result-'+form_id ).show();
                            return;
                        }

			if ( 1 === page ) {
				search_form.addClass('processing');
			}

			if( search_term.length >= min_no_for_search ) {

				if ( 1 === page ) {
                                    $( '#is-ajax-search-result-'+form_id+', #is-ajax-search-details-'+form_id ).hide();
                                    if ( search_form.hasClass( 'is-form-style-1' ) ) {
                                        var button_width = search_form.find('.is-search-submit').outerWidth()+5;
                                        search_form.find('.is-loader-image').css('right', button_width + 'px' );
                                    }
                                    search_form.find('.is-loader-image').show();
				}

				var object = {
					action: 'is_ajax_load_posts',
					page: page,
                                        security: IvoryAjaxVars.ajax_nonce,
				};

				var data = search_form.serialize() + '&' + $.param(object);
                                
                                if ( 0 === search_form.find('input[name="id"]').length ) {
                                    data += '&id=' +form_id;
                                }

                                if ( ajax && ajax.readystate !== 4 ) {
                                    ajax.abort();
                                }
				ajax = $.ajax({
					url : IvoryAjaxVars.ajaxurl,
					data : data,
					type : 'POST',
					success : function( data ) {
                        if ( typeof IvorySearchVars !== "undefined" &&  typeof IvorySearchVars.is_analytics_enabled !== "undefined" ) {
                            var results_found = $( data ).find('.is-ajax-search-no-result').length ? 'Nothing Found' : 'Results Found';
                            ivory_search_analytics( form_id, search_term, results_found );
                        }
						search_form.find('.is-loader-image').hide();
						search_form.removeClass('processing');

						if ( 1 === page ) {
                                                        var pos = search_form.offset();
                                                        var height = search_form.innerHeight();
                                                        var width = search_form.outerWidth();
                                                        width = ( width < 500 ) ? 500 : width;

                                                        if ( 0 === $('#is-ajax-search-result-'+form_id).length ) {
                                                            $('body').append( '<div id="is-ajax-search-result-'+form_id+'" class="is-ajax-search-result"></div>' );
                                                        }

                                                        $('#is-ajax-search-result-'+form_id).css({
                                                            width: ( width - 10 ) + "px",
                                                        });

                                                        var result_width = $( '#is-ajax-search-result-'+form_id ).outerWidth();
                                                        var window_width = $(window).width();
                                                        var reduce_left_pos = 0;

                                                        if ( ( pos.left + result_width ) > window_width ) {
                                                            reduce_left_pos = ( pos.left + result_width ) - window_width;
                                                        }

                                                        $('#is-ajax-search-result-'+form_id).css({
                                                            top: (pos.top+height) + "px",
                                                            left: (pos.left-reduce_left_pos) + "px",
                                                            width: ( width - 10 ) + "px",
                                                        });
				                                        $('#is-ajax-search-result-'+form_id).show().html( data );
                                                        if ( 0 !== $('#is-ajax-search-details-'+form_id).length ) {
                                                            $('body > #is-ajax-search-details-'+form_id).remove();
                                                        }
                                                        if ( 0 !== $( '#is-ajax-search-result-'+form_id + ' .is-ajax-search-details' ) .length ) {
                                                            $('body').append( '<div id="is-ajax-search-details-'+form_id+'" class="is-ajax-search-details">' + $( '#is-ajax-search-result-'+form_id + ' .is-ajax-search-details' ).html() + '</div>' );
                                                            $( '#is-ajax-search-result-'+form_id + ' .is-ajax-search-details' ).remove();
                                                            var details_width = $( '#is-ajax-search-details-'+form_id ).outerWidth();
                                                            var details_left = pos.left+result_width;
                                                            if ( ( pos.left + result_width + details_width ) > ( window_width + 30 ) ) {
                                                                var temp = pos.left - ( reduce_left_pos + details_width );
                                                                if ( temp > -30 ) {
                                                                    details_left = temp;
                                                                }
                                                            }
                                                            $('#is-ajax-search-details-'+form_id).css({
                                                                top: (pos.top+height) + "px",
                                                                left: (details_left) + "px"
                                                            });
                                                        }
						} else {
                                                        $('#is-ajax-search-result-'+form_id+' .is-show-more-results').remove();
							$('#is-ajax-search-result-'+form_id+' .is-ajax-search-posts').append( data );
                                                        if ( 0 !== $('#is-ajax-search-result-'+form_id+' .is-ajax-search-posts .is-show-more-results').length ){
                                                            $('#is-ajax-search-result-'+form_id ).append( $('#is-ajax-search-result-'+form_id+' .is-ajax-search-posts .is-show-more-results')[0].outerHTML );
                                                            $('#is-ajax-search-result-'+form_id+' .is-ajax-search-posts .is-show-more-results').remove();
                                                        }
                                                        $('#is-ajax-search-details-'+form_id+' .is-ajax-search-posts-details').append( $('#is-ajax-search-result-'+form_id+' .is-ajax-search-items .is-ajax-search-posts-details').html() );
                                                        $('#is-ajax-search-result-'+form_id+' .is-ajax-search-items .is-ajax-search-details').remove();
						}

                        var is_ajax_terms = search_term.trim().split(' ');
                        if (is_ajax_terms.length != 0 && $.isFunction($.fn.is_highlight)  ) {
                            var is_ajax_areas = ['.is-ajax-search-result'];
                            var t = jQuery.support.opacity ? 'mark' : 'span';
                            var area, i, s;
                            for (s in is_ajax_areas){
                                area = $(is_ajax_areas[s]);
                                if (area.length != 0){
                                    for (i in is_ajax_terms){
                                        area.is_highlight(is_ajax_terms[i], t, 'is-highlight term-' + i);
                                        area.find('*').is_highlight(is_ajax_terms[i], t, 'is-highlight term-' + i)
                                    }
                                    break;
                                }
                            }
                        }
                                                $( '#is-ajax-search-result-'+form_id+' .is-ajax-search-items, #is-ajax-search-details-'+form_id+' .is-ajax-search-items' ).css('max-height', result_box_max_height + 'px');
                                                $('.is-ajax-search-items').each(function(index, element){
                                                    new SimpleBar(element);
                                                });
                        $( '.is-ajax-search-result .is-ajax-search-post a' ).on( 'click', function( e ) {
                            $( '#is-popup-wrapper, .is-ajax-search-result, .is-ajax-search-details' ).fadeOut('slow');
                        });

                        $( '.is-ajax-woocommerce-actions .qty' ).on( 'change', function() {
                            $( this ).parent().next().find( '.add_to_cart_button' ).attr( 'data-quantity', $( this ).val() );
                        });
					},
                                        error: function( XMLHttpRequest, textStatus, errorThrown ) {
                                            console.log(XMLHttpRequest.statusText);
                                            if ( 'abort' !== XMLHttpRequest.statusText ) {
                                                console.log( "AJAX request aborted" );
                                            }
                                        }
				});
			} else {
				$( '#is-ajax-search-result-'+form_id ).hide();
				search_form.removeClass('processing');
			}
		}
	} );
};

IVS_AJAX_JS_LOAD();

/**
 * simplebar - v6.3.2
 * Scrollbars, simpler.
 * https://grsmto.github.io/simplebar/
 *
 * Made by Adrien Denat from a fork by Jonathan Nicol
 * Under MIT License
 */

var SimpleBar=function(){"use strict";var t=function(e,i){return t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i])},t(e,i)};function e(t){var e=typeof t;return null!=t&&("object"==e||"function"==e)}var i="object"==typeof global&&global&&global.Object===Object&&global,s="object"==typeof self&&self&&self.Object===Object&&self,r=i||s||Function("return this")(),l=function(){return r.Date.now()},o=/\s/;var n=/^\s+/;function a(t){return t?t.slice(0,function(t){for(var e=t.length;e--&&o.test(t.charAt(e)););return e}(t)+1).replace(n,""):t}var c=r.Symbol,h=Object.prototype,u=h.hasOwnProperty,d=h.toString,p=c?c.toStringTag:void 0;var v=Object.prototype.toString;var f=c?c.toStringTag:void 0;function m(t){return null==t?void 0===t?"[object Undefined]":"[object Null]":f&&f in Object(t)?function(t){var e=u.call(t,p),i=t[p];try{t[p]=void 0;var s=!0}catch(t){}var r=d.call(t);return s&&(e?t[p]=i:delete t[p]),r}(t):function(t){return v.call(t)}(t)}var b=/^[-+]0x[0-9a-f]+$/i,g=/^0b[01]+$/i,x=/^0o[0-7]+$/i,y=parseInt;function E(t){if("number"==typeof t)return t;if(function(t){return"symbol"==typeof t||function(t){return null!=t&&"object"==typeof t}(t)&&"[object Symbol]"==m(t)}(t))return NaN;if(e(t)){var i="function"==typeof t.valueOf?t.valueOf():t;t=e(i)?i+"":i}if("string"!=typeof t)return 0===t?t:+t;t=a(t);var s=g.test(t);return s||x.test(t)?y(t.slice(2),s?2:8):b.test(t)?NaN:+t}var O=Math.max,w=Math.min;function S(t,i,s){var r,o,n,a,c,h,u=0,d=!1,p=!1,v=!0;if("function"!=typeof t)throw new TypeError("Expected a function");function f(e){var i=r,s=o;return r=o=void 0,u=e,a=t.apply(s,i)}function m(t){return u=t,c=setTimeout(g,i),d?f(t):a}function b(t){var e=t-h;return void 0===h||e>=i||e<0||p&&t-u>=n}function g(){var t=l();if(b(t))return x(t);c=setTimeout(g,function(t){var e=i-(t-h);return p?w(e,n-(t-u)):e}(t))}function x(t){return c=void 0,v&&r?f(t):(r=o=void 0,a)}function y(){var t=l(),e=b(t);if(r=arguments,o=this,h=t,e){if(void 0===c)return m(h);if(p)return clearTimeout(c),c=setTimeout(g,i),f(h)}return void 0===c&&(c=setTimeout(g,i)),a}return i=E(i)||0,e(s)&&(d=!!s.leading,n=(p="maxWait"in s)?O(E(s.maxWait)||0,i):n,v="trailing"in s?!!s.trailing:v),y.cancel=function(){void 0!==c&&clearTimeout(c),u=0,r=h=o=c=void 0},y.flush=function(){return void 0===c?a:x(l())},y}var A=function(){return A=Object.assign||function(t){for(var e,i=1,s=arguments.length;i<s;i++)for(var r in e=arguments[i])Object.prototype.hasOwnProperty.call(e,r)&&(t[r]=e[r]);return t},A.apply(this,arguments)};function k(t){return t&&t.ownerDocument&&t.ownerDocument.defaultView?t.ownerDocument.defaultView:window}function W(t){return t&&t.ownerDocument?t.ownerDocument:document}var M=function(t){return Array.prototype.reduce.call(t,(function(t,e){var i=e.name.match(/data-simplebar-(.+)/);if(i){var s=i[1].replace(/\W+(.)/g,(function(t,e){return e.toUpperCase()}));switch(e.value){case"true":t[s]=!0;break;case"false":t[s]=!1;break;case void 0:t[s]=!0;break;default:t[s]=e.value}}return t}),{})};function N(t,e){var i;t&&(i=t.classList).add.apply(i,e.split(" "))}function L(t,e){t&&e.split(" ").forEach((function(e){t.classList.remove(e)}))}function z(t){return".".concat(t.split(" ").join("."))}var C=!("undefined"==typeof window||!window.document||!window.document.createElement),T=Object.freeze({__proto__:null,addClasses:N,canUseDOM:C,classNamesToQuery:z,getElementDocument:W,getElementWindow:k,getOptions:M,removeClasses:L}),D=null,R=null;function V(){if(null===D){if("undefined"==typeof document)return D=0;var t=document.body,e=document.createElement("div");e.classList.add("simplebar-hide-scrollbar"),t.appendChild(e);var i=e.getBoundingClientRect().right;t.removeChild(e),D=i}return D}C&&window.addEventListener("resize",(function(){R!==window.devicePixelRatio&&(R=window.devicePixelRatio,D=null)}));var H=k,j=W,B=M,_=N,q=L,P=z,X=function(){function t(i,s){void 0===s&&(s={});var r=this;if(this.removePreventClickId=null,this.minScrollbarWidth=20,this.stopScrollDelay=175,this.isScrolling=!1,this.isMouseEntering=!1,this.isDragging=!1,this.scrollXTicking=!1,this.scrollYTicking=!1,this.wrapperEl=null,this.contentWrapperEl=null,this.contentEl=null,this.offsetEl=null,this.maskEl=null,this.placeholderEl=null,this.heightAutoObserverWrapperEl=null,this.heightAutoObserverEl=null,this.rtlHelpers=null,this.scrollbarWidth=0,this.resizeObserver=null,this.mutationObserver=null,this.elStyles=null,this.isRtl=null,this.mouseX=0,this.mouseY=0,this.onMouseMove=function(){},this.onWindowResize=function(){},this.onStopScrolling=function(){},this.onMouseEntered=function(){},this.onScroll=function(){var t=H(r.el);r.scrollXTicking||(t.requestAnimationFrame(r.scrollX),r.scrollXTicking=!0),r.scrollYTicking||(t.requestAnimationFrame(r.scrollY),r.scrollYTicking=!0),r.isScrolling||(r.isScrolling=!0,_(r.el,r.classNames.scrolling)),r.showScrollbar("x"),r.showScrollbar("y"),r.onStopScrolling()},this.scrollX=function(){r.axis.x.isOverflowing&&r.positionScrollbar("x"),r.scrollXTicking=!1},this.scrollY=function(){r.axis.y.isOverflowing&&r.positionScrollbar("y"),r.scrollYTicking=!1},this._onStopScrolling=function(){q(r.el,r.classNames.scrolling),r.options.autoHide&&(r.hideScrollbar("x"),r.hideScrollbar("y")),r.isScrolling=!1},this.onMouseEnter=function(){r.isMouseEntering||(_(r.el,r.classNames.mouseEntered),r.showScrollbar("x"),r.showScrollbar("y"),r.isMouseEntering=!0),r.onMouseEntered()},this._onMouseEntered=function(){q(r.el,r.classNames.mouseEntered),r.options.autoHide&&(r.hideScrollbar("x"),r.hideScrollbar("y")),r.isMouseEntering=!1},this._onMouseMove=function(t){r.mouseX=t.clientX,r.mouseY=t.clientY,(r.axis.x.isOverflowing||r.axis.x.forceVisible)&&r.onMouseMoveForAxis("x"),(r.axis.y.isOverflowing||r.axis.y.forceVisible)&&r.onMouseMoveForAxis("y")},this.onMouseLeave=function(){r.onMouseMove.cancel(),(r.axis.x.isOverflowing||r.axis.x.forceVisible)&&r.onMouseLeaveForAxis("x"),(r.axis.y.isOverflowing||r.axis.y.forceVisible)&&r.onMouseLeaveForAxis("y"),r.mouseX=-1,r.mouseY=-1},this._onWindowResize=function(){r.scrollbarWidth=r.getScrollbarWidth(),r.hideNativeScrollbar()},this.onPointerEvent=function(t){var e,i;r.axis.x.track.el&&r.axis.y.track.el&&r.axis.x.scrollbar.el&&r.axis.y.scrollbar.el&&(r.axis.x.track.rect=r.axis.x.track.el.getBoundingClientRect(),r.axis.y.track.rect=r.axis.y.track.el.getBoundingClientRect(),(r.axis.x.isOverflowing||r.axis.x.forceVisible)&&(e=r.isWithinBounds(r.axis.x.track.rect)),(r.axis.y.isOverflowing||r.axis.y.forceVisible)&&(i=r.isWithinBounds(r.axis.y.track.rect)),(e||i)&&(t.stopPropagation(),"pointerdown"===t.type&&"touch"!==t.pointerType&&(e&&(r.axis.x.scrollbar.rect=r.axis.x.scrollbar.el.getBoundingClientRect(),r.isWithinBounds(r.axis.x.scrollbar.rect)?r.onDragStart(t,"x"):r.onTrackClick(t,"x")),i&&(r.axis.y.scrollbar.rect=r.axis.y.scrollbar.el.getBoundingClientRect(),r.isWithinBounds(r.axis.y.scrollbar.rect)?r.onDragStart(t,"y"):r.onTrackClick(t,"y")))))},this.drag=function(e){var i,s,l,o,n,a,c,h,u,d,p;if(r.draggedAxis&&r.contentWrapperEl){var v=r.axis[r.draggedAxis].track,f=null!==(s=null===(i=v.rect)||void 0===i?void 0:i[r.axis[r.draggedAxis].sizeAttr])&&void 0!==s?s:0,m=r.axis[r.draggedAxis].scrollbar,b=null!==(o=null===(l=r.contentWrapperEl)||void 0===l?void 0:l[r.axis[r.draggedAxis].scrollSizeAttr])&&void 0!==o?o:0,g=parseInt(null!==(a=null===(n=r.elStyles)||void 0===n?void 0:n[r.axis[r.draggedAxis].sizeAttr])&&void 0!==a?a:"0px",10);e.preventDefault(),e.stopPropagation();var x=("y"===r.draggedAxis?e.pageY:e.pageX)-(null!==(h=null===(c=v.rect)||void 0===c?void 0:c[r.axis[r.draggedAxis].offsetAttr])&&void 0!==h?h:0)-r.axis[r.draggedAxis].dragOffset,y=(x="x"===r.draggedAxis&&r.isRtl?(null!==(d=null===(u=v.rect)||void 0===u?void 0:u[r.axis[r.draggedAxis].sizeAttr])&&void 0!==d?d:0)-m.size-x:x)/(f-m.size)*(b-g);"x"===r.draggedAxis&&r.isRtl&&(y=(null===(p=t.getRtlHelpers())||void 0===p?void 0:p.isScrollingToNegative)?-y:y),r.contentWrapperEl[r.axis[r.draggedAxis].scrollOffsetAttr]=y}},this.onEndDrag=function(t){r.isDragging=!1;var e=j(r.el),i=H(r.el);t.preventDefault(),t.stopPropagation(),q(r.el,r.classNames.dragging),r.onStopScrolling(),e.removeEventListener("mousemove",r.drag,!0),e.removeEventListener("mouseup",r.onEndDrag,!0),r.removePreventClickId=i.setTimeout((function(){e.removeEventListener("click",r.preventClick,!0),e.removeEventListener("dblclick",r.preventClick,!0),r.removePreventClickId=null}))},this.preventClick=function(t){t.preventDefault(),t.stopPropagation()},this.el=i,this.options=A(A({},t.defaultOptions),s),this.classNames=A(A({},t.defaultOptions.classNames),s.classNames),this.axis={x:{scrollOffsetAttr:"scrollLeft",sizeAttr:"width",scrollSizeAttr:"scrollWidth",offsetSizeAttr:"offsetWidth",offsetAttr:"left",overflowAttr:"overflowX",dragOffset:0,isOverflowing:!0,forceVisible:!1,track:{size:null,el:null,rect:null,isVisible:!1},scrollbar:{size:null,el:null,rect:null,isVisible:!1}},y:{scrollOffsetAttr:"scrollTop",sizeAttr:"height",scrollSizeAttr:"scrollHeight",offsetSizeAttr:"offsetHeight",offsetAttr:"top",overflowAttr:"overflowY",dragOffset:0,isOverflowing:!0,forceVisible:!1,track:{size:null,el:null,rect:null,isVisible:!1},scrollbar:{size:null,el:null,rect:null,isVisible:!1}}},"object"!=typeof this.el||!this.el.nodeName)throw new Error("Argument passed to SimpleBar must be an HTML element instead of ".concat(this.el));this.onMouseMove=function(t,i,s){var r=!0,l=!0;if("function"!=typeof t)throw new TypeError("Expected a function");return e(s)&&(r="leading"in s?!!s.leading:r,l="trailing"in s?!!s.trailing:l),S(t,i,{leading:r,maxWait:i,trailing:l})}(this._onMouseMove,64),this.onWindowResize=S(this._onWindowResize,64,{leading:!0}),this.onStopScrolling=S(this._onStopScrolling,this.stopScrollDelay),this.onMouseEntered=S(this._onMouseEntered,this.stopScrollDelay),this.init()}return t.getRtlHelpers=function(){if(t.rtlHelpers)return t.rtlHelpers;var e=document.createElement("div");e.innerHTML='<div class="simplebar-dummy-scrollbar-size"><div></div></div>';var i=e.firstElementChild,s=null==i?void 0:i.firstElementChild;if(!s)return null;document.body.appendChild(i),i.scrollLeft=0;var r=t.getOffset(i),l=t.getOffset(s);i.scrollLeft=-999;var o=t.getOffset(s);return document.body.removeChild(i),t.rtlHelpers={isScrollOriginAtZero:r.left!==l.left,isScrollingToNegative:l.left!==o.left},t.rtlHelpers},t.prototype.getScrollbarWidth=function(){try{return this.contentWrapperEl&&"none"===getComputedStyle(this.contentWrapperEl,"::-webkit-scrollbar").display||"scrollbarWidth"in document.documentElement.style||"-ms-overflow-style"in document.documentElement.style?0:V()}catch(t){return V()}},t.getOffset=function(t){var e=t.getBoundingClientRect(),i=j(t),s=H(t);return{top:e.top+(s.pageYOffset||i.documentElement.scrollTop),left:e.left+(s.pageXOffset||i.documentElement.scrollLeft)}},t.prototype.init=function(){C&&(this.initDOM(),this.rtlHelpers=t.getRtlHelpers(),this.scrollbarWidth=this.getScrollbarWidth(),this.recalculate(),this.initListeners())},t.prototype.initDOM=function(){var t,e;this.wrapperEl=this.el.querySelector(P(this.classNames.wrapper)),this.contentWrapperEl=this.options.scrollableNode||this.el.querySelector(P(this.classNames.contentWrapper)),this.contentEl=this.options.contentNode||this.el.querySelector(P(this.classNames.contentEl)),this.offsetEl=this.el.querySelector(P(this.classNames.offset)),this.maskEl=this.el.querySelector(P(this.classNames.mask)),this.placeholderEl=this.findChild(this.wrapperEl,P(this.classNames.placeholder)),this.heightAutoObserverWrapperEl=this.el.querySelector(P(this.classNames.heightAutoObserverWrapperEl)),this.heightAutoObserverEl=this.el.querySelector(P(this.classNames.heightAutoObserverEl)),this.axis.x.track.el=this.findChild(this.el,"".concat(P(this.classNames.track)).concat(P(this.classNames.horizontal))),this.axis.y.track.el=this.findChild(this.el,"".concat(P(this.classNames.track)).concat(P(this.classNames.vertical))),this.axis.x.scrollbar.el=(null===(t=this.axis.x.track.el)||void 0===t?void 0:t.querySelector(P(this.classNames.scrollbar)))||null,this.axis.y.scrollbar.el=(null===(e=this.axis.y.track.el)||void 0===e?void 0:e.querySelector(P(this.classNames.scrollbar)))||null,this.options.autoHide||(_(this.axis.x.scrollbar.el,this.classNames.visible),_(this.axis.y.scrollbar.el,this.classNames.visible))},t.prototype.initListeners=function(){var t,e=this,i=H(this.el);if(this.el.addEventListener("mouseenter",this.onMouseEnter),this.el.addEventListener("pointerdown",this.onPointerEvent,!0),this.el.addEventListener("mousemove",this.onMouseMove),this.el.addEventListener("mouseleave",this.onMouseLeave),null===(t=this.contentWrapperEl)||void 0===t||t.addEventListener("scroll",this.onScroll),i.addEventListener("resize",this.onWindowResize),this.contentEl){if(window.ResizeObserver){var s=!1,r=i.ResizeObserver||ResizeObserver;this.resizeObserver=new r((function(){s&&i.requestAnimationFrame((function(){e.recalculate()}))})),this.resizeObserver.observe(this.el),this.resizeObserver.observe(this.contentEl),i.requestAnimationFrame((function(){s=!0}))}this.mutationObserver=new i.MutationObserver((function(){i.requestAnimationFrame((function(){e.recalculate()}))})),this.mutationObserver.observe(this.contentEl,{childList:!0,subtree:!0,characterData:!0})}},t.prototype.recalculate=function(){if(this.heightAutoObserverEl&&this.contentEl&&this.contentWrapperEl&&this.wrapperEl&&this.placeholderEl){var t=H(this.el);this.elStyles=t.getComputedStyle(this.el),this.isRtl="rtl"===this.elStyles.direction;var e=this.contentEl.offsetWidth,i=this.heightAutoObserverEl.offsetHeight<=1,s=this.heightAutoObserverEl.offsetWidth<=1||e>0,r=this.contentWrapperEl.offsetWidth,l=this.elStyles.overflowX,o=this.elStyles.overflowY;this.contentEl.style.padding="".concat(this.elStyles.paddingTop," ").concat(this.elStyles.paddingRight," ").concat(this.elStyles.paddingBottom," ").concat(this.elStyles.paddingLeft),this.wrapperEl.style.margin="-".concat(this.elStyles.paddingTop," -").concat(this.elStyles.paddingRight," -").concat(this.elStyles.paddingBottom," -").concat(this.elStyles.paddingLeft);var n=this.contentEl.scrollHeight,a=this.contentEl.scrollWidth;this.contentWrapperEl.style.height=i?"auto":"100%",this.placeholderEl.style.width=s?"".concat(e||a,"px"):"auto",this.placeholderEl.style.height="".concat(n,"px");var c=this.contentWrapperEl.offsetHeight;this.axis.x.isOverflowing=0!==e&&a>e,this.axis.y.isOverflowing=n>c,this.axis.x.isOverflowing="hidden"!==l&&this.axis.x.isOverflowing,this.axis.y.isOverflowing="hidden"!==o&&this.axis.y.isOverflowing,this.axis.x.forceVisible="x"===this.options.forceVisible||!0===this.options.forceVisible,this.axis.y.forceVisible="y"===this.options.forceVisible||!0===this.options.forceVisible,this.hideNativeScrollbar();var h=this.axis.x.isOverflowing?this.scrollbarWidth:0,u=this.axis.y.isOverflowing?this.scrollbarWidth:0;this.axis.x.isOverflowing=this.axis.x.isOverflowing&&a>r-u,this.axis.y.isOverflowing=this.axis.y.isOverflowing&&n>c-h,this.axis.x.scrollbar.size=this.getScrollbarSize("x"),this.axis.y.scrollbar.size=this.getScrollbarSize("y"),this.axis.x.scrollbar.el&&(this.axis.x.scrollbar.el.style.width="".concat(this.axis.x.scrollbar.size,"px")),this.axis.y.scrollbar.el&&(this.axis.y.scrollbar.el.style.height="".concat(this.axis.y.scrollbar.size,"px")),this.positionScrollbar("x"),this.positionScrollbar("y"),this.toggleTrackVisibility("x"),this.toggleTrackVisibility("y")}},t.prototype.getScrollbarSize=function(t){var e,i;if(void 0===t&&(t="y"),!this.axis[t].isOverflowing||!this.contentEl)return 0;var s,r=this.contentEl[this.axis[t].scrollSizeAttr],l=null!==(i=null===(e=this.axis[t].track.el)||void 0===e?void 0:e[this.axis[t].offsetSizeAttr])&&void 0!==i?i:0,o=l/r;return s=Math.max(~~(o*l),this.options.scrollbarMinSize),this.options.scrollbarMaxSize&&(s=Math.min(s,this.options.scrollbarMaxSize)),s},t.prototype.positionScrollbar=function(e){var i,s,r;void 0===e&&(e="y");var l=this.axis[e].scrollbar;if(this.axis[e].isOverflowing&&this.contentWrapperEl&&l.el&&this.elStyles){var o=this.contentWrapperEl[this.axis[e].scrollSizeAttr],n=(null===(i=this.axis[e].track.el)||void 0===i?void 0:i[this.axis[e].offsetSizeAttr])||0,a=parseInt(this.elStyles[this.axis[e].sizeAttr],10),c=this.contentWrapperEl[this.axis[e].scrollOffsetAttr];c="x"===e&&this.isRtl&&(null===(s=t.getRtlHelpers())||void 0===s?void 0:s.isScrollOriginAtZero)?-c:c,"x"===e&&this.isRtl&&(c=(null===(r=t.getRtlHelpers())||void 0===r?void 0:r.isScrollingToNegative)?c:-c);var h=c/(o-a),u=~~((n-l.size)*h);u="x"===e&&this.isRtl?-u+(n-l.size):u,l.el.style.transform="x"===e?"translate3d(".concat(u,"px, 0, 0)"):"translate3d(0, ".concat(u,"px, 0)")}},t.prototype.toggleTrackVisibility=function(t){void 0===t&&(t="y");var e=this.axis[t].track.el,i=this.axis[t].scrollbar.el;e&&i&&this.contentWrapperEl&&(this.axis[t].isOverflowing||this.axis[t].forceVisible?(e.style.visibility="visible",this.contentWrapperEl.style[this.axis[t].overflowAttr]="scroll",this.el.classList.add("".concat(this.classNames.scrollable,"-").concat(t))):(e.style.visibility="hidden",this.contentWrapperEl.style[this.axis[t].overflowAttr]="hidden",this.el.classList.remove("".concat(this.classNames.scrollable,"-").concat(t))),this.axis[t].isOverflowing?i.style.display="block":i.style.display="none")},t.prototype.showScrollbar=function(t){void 0===t&&(t="y"),this.axis[t].isOverflowing&&!this.axis[t].scrollbar.isVisible&&(_(this.axis[t].scrollbar.el,this.classNames.visible),this.axis[t].scrollbar.isVisible=!0)},t.prototype.hideScrollbar=function(t){void 0===t&&(t="y"),this.isDragging||this.axis[t].isOverflowing&&this.axis[t].scrollbar.isVisible&&(q(this.axis[t].scrollbar.el,this.classNames.visible),this.axis[t].scrollbar.isVisible=!1)},t.prototype.hideNativeScrollbar=function(){this.offsetEl&&(this.offsetEl.style[this.isRtl?"left":"right"]=this.axis.y.isOverflowing||this.axis.y.forceVisible?"-".concat(this.scrollbarWidth,"px"):"0px",this.offsetEl.style.bottom=this.axis.x.isOverflowing||this.axis.x.forceVisible?"-".concat(this.scrollbarWidth,"px"):"0px")},t.prototype.onMouseMoveForAxis=function(t){void 0===t&&(t="y");var e=this.axis[t];e.track.el&&e.scrollbar.el&&(e.track.rect=e.track.el.getBoundingClientRect(),e.scrollbar.rect=e.scrollbar.el.getBoundingClientRect(),this.isWithinBounds(e.track.rect)?(this.showScrollbar(t),_(e.track.el,this.classNames.hover),this.isWithinBounds(e.scrollbar.rect)?_(e.scrollbar.el,this.classNames.hover):q(e.scrollbar.el,this.classNames.hover)):(q(e.track.el,this.classNames.hover),this.options.autoHide&&this.hideScrollbar(t)))},t.prototype.onMouseLeaveForAxis=function(t){void 0===t&&(t="y"),q(this.axis[t].track.el,this.classNames.hover),q(this.axis[t].scrollbar.el,this.classNames.hover),this.options.autoHide&&this.hideScrollbar(t)},t.prototype.onDragStart=function(t,e){var i;void 0===e&&(e="y"),this.isDragging=!0;var s=j(this.el),r=H(this.el),l=this.axis[e].scrollbar,o="y"===e?t.pageY:t.pageX;this.axis[e].dragOffset=o-((null===(i=l.rect)||void 0===i?void 0:i[this.axis[e].offsetAttr])||0),this.draggedAxis=e,_(this.el,this.classNames.dragging),s.addEventListener("mousemove",this.drag,!0),s.addEventListener("mouseup",this.onEndDrag,!0),null===this.removePreventClickId?(s.addEventListener("click",this.preventClick,!0),s.addEventListener("dblclick",this.preventClick,!0)):(r.clearTimeout(this.removePreventClickId),this.removePreventClickId=null)},t.prototype.onTrackClick=function(t,e){var i,s,r,l,o=this;void 0===e&&(e="y");var n=this.axis[e];if(this.options.clickOnTrack&&n.scrollbar.el&&this.contentWrapperEl){t.preventDefault();var a=H(this.el);this.axis[e].scrollbar.rect=n.scrollbar.el.getBoundingClientRect();var c=null!==(s=null===(i=this.axis[e].scrollbar.rect)||void 0===i?void 0:i[this.axis[e].offsetAttr])&&void 0!==s?s:0,h=parseInt(null!==(l=null===(r=this.elStyles)||void 0===r?void 0:r[this.axis[e].sizeAttr])&&void 0!==l?l:"0px",10),u=this.contentWrapperEl[this.axis[e].scrollOffsetAttr],d=("y"===e?this.mouseY-c:this.mouseX-c)<0?-1:1,p=-1===d?u-h:u+h,v=function(){o.contentWrapperEl&&(-1===d?u>p&&(u-=40,o.contentWrapperEl[o.axis[e].scrollOffsetAttr]=u,a.requestAnimationFrame(v)):u<p&&(u+=40,o.contentWrapperEl[o.axis[e].scrollOffsetAttr]=u,a.requestAnimationFrame(v)))};v()}},t.prototype.getContentElement=function(){return this.contentEl},t.prototype.getScrollElement=function(){return this.contentWrapperEl},t.prototype.removeListeners=function(){var t=H(this.el);this.el.removeEventListener("mouseenter",this.onMouseEnter),this.el.removeEventListener("pointerdown",this.onPointerEvent,!0),this.el.removeEventListener("mousemove",this.onMouseMove),this.el.removeEventListener("mouseleave",this.onMouseLeave),this.contentWrapperEl&&this.contentWrapperEl.removeEventListener("scroll",this.onScroll),t.removeEventListener("resize",this.onWindowResize),this.mutationObserver&&this.mutationObserver.disconnect(),this.resizeObserver&&this.resizeObserver.disconnect(),this.onMouseMove.cancel(),this.onWindowResize.cancel(),this.onStopScrolling.cancel(),this.onMouseEntered.cancel()},t.prototype.unMount=function(){this.removeListeners()},t.prototype.isWithinBounds=function(t){return this.mouseX>=t.left&&this.mouseX<=t.left+t.width&&this.mouseY>=t.top&&this.mouseY<=t.top+t.height},t.prototype.findChild=function(t,e){var i=t.matches||t.webkitMatchesSelector||t.mozMatchesSelector||t.msMatchesSelector;return Array.prototype.filter.call(t.children,(function(t){return i.call(t,e)}))[0]},t.rtlHelpers=null,t.defaultOptions={forceVisible:!1,clickOnTrack:!0,scrollbarMinSize:25,scrollbarMaxSize:0,ariaLabel:"scrollable content",tabIndex:0,classNames:{contentEl:"simplebar-content",contentWrapper:"simplebar-content-wrapper",offset:"simplebar-offset",mask:"simplebar-mask",wrapper:"simplebar-wrapper",placeholder:"simplebar-placeholder",scrollbar:"simplebar-scrollbar",track:"simplebar-track",heightAutoObserverWrapperEl:"simplebar-height-auto-observer-wrapper",heightAutoObserverEl:"simplebar-height-auto-observer",visible:"simplebar-visible",horizontal:"simplebar-horizontal",vertical:"simplebar-vertical",hover:"simplebar-hover",dragging:"simplebar-dragging",scrolling:"simplebar-scrolling",scrollable:"simplebar-scrollable",mouseEntered:"simplebar-mouse-entered"},scrollableNode:null,contentNode:null,autoHide:!0},t.getOptions=B,t.helpers=T,t}(),Y=X.helpers,F=Y.getOptions,I=Y.addClasses,U=Y.canUseDOM,$=function(e){function i(){for(var t=[],s=0;s<arguments.length;s++)t[s]=arguments[s];var r=e.apply(this,t)||this;return i.instances.set(t[0],r),r}return function(e,i){if("function"!=typeof i&&null!==i)throw new TypeError("Class extends value "+String(i)+" is not a constructor or null");function s(){this.constructor=e}t(e,i),e.prototype=null===i?Object.create(i):(s.prototype=i.prototype,new s)}(i,e),i.initDOMLoadedElements=function(){document.removeEventListener("DOMContentLoaded",this.initDOMLoadedElements),window.removeEventListener("load",this.initDOMLoadedElements),Array.prototype.forEach.call(document.querySelectorAll("[data-simplebar]"),(function(t){"init"===t.getAttribute("data-simplebar")||i.instances.has(t)||new i(t,F(t.attributes))}))},i.removeObserver=function(){var t;null===(t=i.globalObserver)||void 0===t||t.disconnect()},i.prototype.initDOM=function(){var t,e,i,s=this;if(!Array.prototype.filter.call(this.el.children,(function(t){return t.classList.contains(s.classNames.wrapper)})).length){for(this.wrapperEl=document.createElement("div"),this.contentWrapperEl=document.createElement("div"),this.offsetEl=document.createElement("div"),this.maskEl=document.createElement("div"),this.contentEl=document.createElement("div"),this.placeholderEl=document.createElement("div"),this.heightAutoObserverWrapperEl=document.createElement("div"),this.heightAutoObserverEl=document.createElement("div"),I(this.wrapperEl,this.classNames.wrapper),I(this.contentWrapperEl,this.classNames.contentWrapper),I(this.offsetEl,this.classNames.offset),I(this.maskEl,this.classNames.mask),I(this.contentEl,this.classNames.contentEl),I(this.placeholderEl,this.classNames.placeholder),I(this.heightAutoObserverWrapperEl,this.classNames.heightAutoObserverWrapperEl),I(this.heightAutoObserverEl,this.classNames.heightAutoObserverEl);this.el.firstChild;)this.contentEl.appendChild(this.el.firstChild);this.contentWrapperEl.appendChild(this.contentEl),this.offsetEl.appendChild(this.contentWrapperEl),this.maskEl.appendChild(this.offsetEl),this.heightAutoObserverWrapperEl.appendChild(this.heightAutoObserverEl),this.wrapperEl.appendChild(this.heightAutoObserverWrapperEl),this.wrapperEl.appendChild(this.maskEl),this.wrapperEl.appendChild(this.placeholderEl),this.el.appendChild(this.wrapperEl),null===(t=this.contentWrapperEl)||void 0===t||t.setAttribute("tabindex",this.options.tabIndex.toString()),null===(e=this.contentWrapperEl)||void 0===e||e.setAttribute("role","region"),null===(i=this.contentWrapperEl)||void 0===i||i.setAttribute("aria-label",this.options.ariaLabel)}if(!this.axis.x.track.el||!this.axis.y.track.el){var r=document.createElement("div"),l=document.createElement("div");I(r,this.classNames.track),I(l,this.classNames.scrollbar),r.appendChild(l),this.axis.x.track.el=r.cloneNode(!0),I(this.axis.x.track.el,this.classNames.horizontal),this.axis.y.track.el=r.cloneNode(!0),I(this.axis.y.track.el,this.classNames.vertical),this.el.appendChild(this.axis.x.track.el),this.el.appendChild(this.axis.y.track.el)}X.prototype.initDOM.call(this),this.el.setAttribute("data-simplebar","init")},i.prototype.unMount=function(){X.prototype.unMount.call(this),i.instances.delete(this.el)},i.initHtmlApi=function(){this.initDOMLoadedElements=this.initDOMLoadedElements.bind(this),"undefined"!=typeof MutationObserver&&(this.globalObserver=new MutationObserver(i.handleMutations),this.globalObserver.observe(document,{childList:!0,subtree:!0})),"complete"===document.readyState||"loading"!==document.readyState&&!document.documentElement.doScroll?window.setTimeout(this.initDOMLoadedElements):(document.addEventListener("DOMContentLoaded",this.initDOMLoadedElements),window.addEventListener("load",this.initDOMLoadedElements))},i.handleMutations=function(t){t.forEach((function(t){t.addedNodes.forEach((function(t){1===t.nodeType&&(t.hasAttribute("data-simplebar")?!i.instances.has(t)&&document.documentElement.contains(t)&&new i(t,F(t.attributes)):t.querySelectorAll("[data-simplebar]").forEach((function(t){"init"!==t.getAttribute("data-simplebar")&&!i.instances.has(t)&&document.documentElement.contains(t)&&new i(t,F(t.attributes))})))})),t.removedNodes.forEach((function(t){var e;1===t.nodeType&&("init"===t.getAttribute("data-simplebar")?!document.documentElement.contains(t)&&(null===(e=i.instances.get(t))||void 0===e||e.unMount()):Array.prototype.forEach.call(t.querySelectorAll('[data-simplebar="init"]'),(function(t){var e;!document.documentElement.contains(t)&&(null===(e=i.instances.get(t))||void 0===e||e.unMount())})))}))}))},i.instances=new WeakMap,i}(X);return U&&$.initHtmlApi(),$}();