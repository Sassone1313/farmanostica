/**
 * WordPress Blocks Entry Point
 *
 * This is the main entry point for all blocks in this plugin.
 * @wordpress/scripts looks for this file as the default entry.
 */

import './google-fonts/index.js';